var keys=JSON.parse(document.getElementById("keys").innerHTML);
var data=JSON.parse(document.getElementById("data").innerHTML);
var data1=Object.values(data);
var data2;
for (i=0;i<keys.length;i++)
{
data2=JSON.parse(data1[i]);

document.getElementById("data").remove();
document.getElementById("keys").remove();
resetcol(data2.tend,data2.tstart,data2.place,data2.col,data2.name,data2.co,data2.clr)
}

function resetcol(tend, tstart, place, col,name,co,clr) {
    var c = 0;
    tstart = Number(tstart);
    tend = Number(tend); 
    col = Number(col);
    while (tstart != tend) {
        if(c==0)
        {
            if (tend % 100 != 0) {
                tend =tend- 30;
            }
            else {
                tend =tend- 70;
            }

        }if (tstart==tend){
            document.getElementById(place + tstart).innerHTML="שם:"+name+"<br/>"+"שם מדריך"+co;
            document.getElementById(place + tstart).style.backgroundColor=clr;
    tstart=tend;
}
else{
         c++;
        //    document.getElementById(place + tend).style.columnSpan = "0";
        // var placeend = document.getElementById(place + tend);
        // var test = document.getElementById("5");
        //  var parent = document.getElementById("table");
        // parent.removeChild(test);
        //   $("#" + place + tend).remove();
        var row = document.getElementById(place + tend);
        row.remove();

        console.log(place + tend);
        if (tend % 100 != 0) {
            tend -= 30;
        }
        else {
            tend -= 70
        }
    }
    document.getElementById(place + tstart).rowSpan = c+1;
    document.getElementById(place + tstart).innerHTML="שם:"+name+"<br/>"+"שם מדריך"+co;
    document.getElementById(place + tstart).style.backgroundColor=clr;
}}