const express = require('express');
const app = express();
const fs = require('fs');

var admin = require("firebase-admin");
// please change the uri of the service acount, I will send you the token file with this code
var serviceAccount = require('Z:/test-40ac5-firebase-adminsdk-1tzdj-fd9bc7172c.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://test-40ac5.firebaseio.com"
});
var db = admin.database();
var ref = db.ref('/');

var normal = ref.child("normal")
var special = ref.child("special")
//edit normal days
function editnormal(day,activity,value)
{
    normal.child(day).child(activity).set(value)
}
//edit special occasions
function editdate(date,activity,value)
{
    special.child(date).child(activity).set(value)
}
//get normal days
async function getnormal(day)
{
    var a = await normal.child(day).once('value',function(snapshot)
    {
        return snapshot
    });
    return JSON.parse(JSON.stringify(a))
}
//get special occasions
async function getdate(date)
{
    var a = await special.child(date).once('value',function(snapshot)
    {
        return snapshot
    });
    return JSON.parse(JSON.stringify(a))
}
//editnormal("sunday","jumping into a pull of acid","{'pain':'a lot'}")
//editnormal("monday","pool","THEY CLOSED IT SO YOU WOULD HAVE NO FUN")
//editdate("2-1-2019","AAAAAAAAAA","I'M BURNING ALIVE")



//tests
//editnormal("sunday","patting cats","{funlevel:5000000000}")
//this function is an example of how to use getnormal(),getdate works the same way,
async function read()
{
    
    console.log(await getdate("2-1-2019"))
}
read()