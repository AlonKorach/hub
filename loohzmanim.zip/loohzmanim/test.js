﻿const express = require('express');
const app = express();
var fs = require('fs');
const bodyPraser = require('body-parser');
app.use(bodyPraser.json());
app.use(bodyPraser.urlencoded({ extended: true }));
//app.set('view engine', 'ejs');
//app.engine('html', require('ejs').renderFile);

//var admin = require("firebase-admin");

/*var serviceAccount = require(__dirname + "/database-1-21a56-firebase-adminsdk-4v74q-b3db828a29.json");
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://database-1-21a56.firebaseio.com"
});*/


//var db = admin.database();
//var ref = db.ref("/")

const port = 3000;

app.get('/login', (req, res) => login(req, res))

function login(req, res) {
    res.sendFile(__dirname + '/login.html');
    
}
var user = "yossi";
var password = "12345";
var movies = "lion king 4";

additem(user, password, movies)
readMovie(user);
function additem(user, password, movies) {
    var itemsRef = ref.child("items")
    var newItemRef = itemsRef.push();
    newItemRef.set({
        "User": user,
        "password": password,
        "movies": movies
        
    })

}

function readMovie(movie) {
    var itemRef = ref.child("items/" + movie);
    itemRef.on("value", function (snapshot) {
        console.log(snapshot.val());
    }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
    });
}



var admin = { name: "admin", movie: ["king", "harry potter", "robin hood"] };
var yossi = { name: "yossi", movie: ["lion king", "pu the bear", "star wars 7"] };
var john = { name: "john", movie: ["sausge party", "deadpool", "deadpool 2"] };


app.post('/login', function login(req, res) {
    var user = req.body.user;
    var pass = req.body.pass;
    var data = JSON.parse(user + ".json");
    //var userd=usercheck(user, pass);
    userd = data.movie

    dbres.render('../HtmlPage.ejs', { user: user, userd: userd });
    //   res.sendFile(__dirname, + '/htmlpage.ejs'); 
});

app.get('/register', register);

function register(req, res) {
    res.sendFile(__dirname + '/reg.html');
}

app.post('/register', function reg(req, res) {
    var newuser = req.body.newuser;
    var newpass = req.body.newpass;
    var movie1 = req.body.movie1;
    var movie2 = req.body.movie2;
    var movie3 = req.body.movie3;
    var movies = [movie1, movie2, movie3];
    if (!checknew(newuser)) {
        userfile = newuser + ".json";
        data = { name: newuser, pass: newpass, movie: [movie1, movie2, movie3] };
        fs.writeFile(__dirname + "/" + userfile, JSON.stringify(data), function (err) {
            if (err) throw err;
            console.log('started Saving!')
        });
    }
})

function checknew(newuser) {
    return fs.exictsync(newuser = ".json")
}


function usercheck(user, pass) {
    return true;
    if (user == "yossi") {

        return yossi.movie
    }
    if (user == "admin") {
        return admin.movie
    }

}

function admin(user, pass) {
    if (user == "admin" && pass == "123456") {
        return true;
    }
}

app.listen(3000)