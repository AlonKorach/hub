const express = require('express');
const app = express();
const fs = require('fs');

var admin = require("firebase-admin");
// please change the uri of the service acount, I will send you the token file with this code
var serviceAccount = require('Z:/test-40ac5-firebase-adminsdk-1tzdj-fd9bc7172c.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://test-40ac5.firebaseio.com"
});
var db = admin.database();
var ref = db.ref('/');

var normal = ref.child("normal")
var special = ref.child("special")

//USE THESE
async function getnormal(day)
{
    var a = await normal.child(day(day)).once('value',function(snapshot)
    {
        return snapshot
    });
    return JSON.parse(JSON.stringify(a))
}
function removedate(date)
{
    special.child(date).remove()
}
function actremovenormal(date,activity)
{
    normal.child(date).child(activity).remove()
}
function actremovedate(date,activity)
{
    var a = await getbdate(date)
    if(a == null)
    {
        var b = date.split("-")
        var c = new Date(parseInt(b[2]),parseInt(b[1]),parseInt(b[0]),1,1,1,1)
        var nor = getnormal(day(c.getDay()))
        setdate(date,nor)
    }
    actremovebdate(date,activity)
}
function editdate(date,activity,value)
{
    var a = await getbdate(date)
    if(a == null)
    {
        var b = date.split("-")
        var c = new Date(parseInt(b[2]),parseInt(b[1]),parseInt(b[0]),1,1,1,1)
        var nor = getnormal(day(c.getDay()))
        setdate(date,nor)
    }
    editbdate(date,activity,value)
}
async function getdate(date)
{
    var a = await getbdate(date)
    if(a != null)
    { return a;}else
    {
        var b = date.split("-")
        var c = new Date(parseInt(b[2]),parseInt(b[1]),parseInt(b[0]),1,1,1,1)
        var nor = getnormal(day(c.getDay()))
        setdate(date,nor)
        return nor;
    }
}
//edit normal days
function editnormal(day,activity,value)
{
    normal.child(day).child(activity).set(value)
}



//DON'T USE THESE, THEY ARE MADE FOR THE USE OF OTHER COMMANDS
async function getbdate(date)
{
    var a = await special.child(date).once('value',function(snapshot)
    {
        return snapshot
    });
    return JSON.parse(JSON.stringify(a))
}
function day(da)
{
    if(da>6||da<0)return null;
    switch(da)
    {
        case 0: return "Sunday"
        case 1: return "Monday"
        case 2: return "Tuesday"
        case 3: return "Wednesday"
        case 4: return "Thursday"
        case 5: return "Friday"
        case 6: return "Saturday"
    }
}
function editbdate(date,activity,value)
{
    special.child(date).child(activity).set(value)
}
function setdate(date,value)
{
    special.child(date).set(value)
}
function actremovebdate(date,activity)
{
    special.child(date).child(activity).remove()
}
