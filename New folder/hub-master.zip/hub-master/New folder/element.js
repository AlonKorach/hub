var XFoo = window.customElements.define('x-foo', {
  prototype: Object.create(HTMLElement.prototype)
});
